<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=shopomy',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
